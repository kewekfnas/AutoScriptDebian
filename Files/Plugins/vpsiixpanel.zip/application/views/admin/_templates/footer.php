<?php
defined('BASEPATH') OR exit('No direct script access allowed');

?>
<!-- blog promotion ends -->


<footer class="container text-center">
    
      
      <div class="copyrights" style="margin-top:25px;">
            <p>VPSIIX &copy; 2020, All Rights Reserved
                <br>
                <span>Develop By: Ahmad Fauzan</span></p>
            <p><a href="https://fb.com/ahmadfauzanhabibi" target="_blank">Facebook <i class="fa fa-facebook-square" aria-hidden="true"></i> </a></p>
        </div>
    
</footer>

</section>	
	
	
	<script src="<?php echo base_url('assets/panel/jquery/jquery.min.js') ?>" type="text/javascript"></script>
	
    <script src="<?php echo base_url('assets/panel/bootstrap/js/bootstrap.min.js') ?>"></script>
    
    <script src="<?php echo base_url('assets/panel/custom/js/custom.js') ?>"></script>
    	
     
</body>
</html>

