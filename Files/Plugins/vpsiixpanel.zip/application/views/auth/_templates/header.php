<?php
defined('BASEPATH') OR exit('No direct script access allowed');

?>
<!DOCTYPE html>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
  <meta charset="UTF-8">
  <title>Panel Reseller | VPSIIX</title>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="<?php echo base_url('assets/panel/custom/css/login.css'); ?>" media="screen" type="text/css">
  <link rel="stylesheet" href="<?php echo base_url('assets/panel/custom/css/css.css'); ?>" media="screen" type="text/css">
  <link rel="stylesheet" href="<?php echo base_url('assets/panel/custom/css/custom-font.css'); ?>" media="screen" type="text/css">
</head>

<body>
<div class="container">
