<?php
defined('BASEPATH') OR exit('No direct script access allowed');

?>
<!-- start footer -->
<div class="container">
      <footer id="footer">
        <div class="row">
          <div class="col-lg-12">

            <ul class="list-unstyled">
              <li class="float-lg-right"><a href="#top">Back to top</a></li>
              <li><a href="http://vpsx.my.id" onclick="pageTracker._link(this.href); return false;">Blog</a></li>
              <li><a href="https://fb.com">Facebok</a></li>
              <li><a href="https://paypal.me/ahmadfauzanhabibi">Donate</a></li>
            </ul>
            <p>Total Account. </p>
            <p>Total Account created by <?php echo ucwords($domain) ?> : <?php echo $total_account ?></p>
			<p>Powered By <a href="http://vpsiix.com" rel="nofollow">VPSIIX</a> Icons from <a href="http://fontawesome.io/" rel="nofollow">Font Awesome</a>. Web fonts from <a href="https://fonts.google.com/" rel="nofollow">Google</a>.</p>
		</div>
       </div>
	   <a href="http://s11.flagcounter.com/more/3Lp"><img src="http://s11.flagcounter.com/count2/3Lp/bg_FFFFFF/txt_000000/border_CCCCCC/columns_4/maxflags_250/viewers_Blog+Visitors/labels_1/pageviews_1/flags_1/percent_0/" style="display:none" alt="Free counters!" border="0"></a>
     </footer>
   </div>

    
    <script src="<?php echo base_url('assets/default/_vendor/popper.js/dist/umd/popper.min.js');?>"></script>
    <script src="<?php echo base_url('assets/default/_vendor/bootstrap/dist/js/bootstrap.min.js');?>"></script>

  </body>
</html>
