<?php
/**
 * Name:    VPSIIX Panel
 * Author:  Ahmad Fauzan
 *          https://fb.com/ahmadfauzanhabibi
 *
 * Added Awesomeness: Ahmad Fauzan
 *
 * Created:  02.10.2020
 *
 * Description:  Panel SSH modul manajemen users.
 *
 * Requirements: PHP5 or above
 *
 * @package    CodeIgniter-vpsiix-panel
 * @author     Ahmad Fauzan
 * 
 * 
 */
defined('BASEPATH') OR exit('No direct script access allowed');

$config['version'] = "1.0";
$config['template'] = 'default';

