<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['default_location']	='indonesia';
$config['default_continent'] ='Asia';

$config['default_service']	='openssh';
$config['default_port']	='22';


